// src/hooks/useAuth.ts
import { useState, useEffect, useCallback } from 'react';
import { bankFacade } from '@/facades/BankFacade';
import { LoginDto, User } from '@/types';
import { useRouter } from 'next/navigation';

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
}

export const useAuth = () => {
  const [state, setState] = useState<AuthState>({
    user: null,
    isAuthenticated: false,
    isLoading: true,
    error: null,
  });

  const router = useRouter();

  // ✅ تحميل auth state من token فقط
  const loadUser = useCallback(() => {
    try {
      const token = localStorage.getItem('accessToken');

      if (!token) {
        setState({
          user: null,
          isAuthenticated: false,
          isLoading: false,
          error: null,
        });
        return;
      }

      // مؤقتًا: لا يوجد endpoint /me
      setState({
        user: null, // سيتم تحميله لاحقًا من backend
        isAuthenticated: true,
        isLoading: false,
        error: null,
      });
    } catch (error) {
      console.error('Auth load error:', error);
      setState({
        user: null,
        isAuthenticated: false,
        isLoading: false,
        error: null,
      });
    }
  }, []);

  useEffect(() => {
    loadUser();
  }, [loadUser]);

  // ✅ Login
  const login = useCallback(async (credentials: LoginDto) => {
    setState((s) => ({ ...s, isLoading: true, error: null }));

    try {
      const response = await bankFacade.login(credentials);

      localStorage.setItem('accessToken', response.access_token);

      setState({
        user: null,
        isAuthenticated: true,
        isLoading: false,
        error: null,
      });

      router.push('/dashboard');
    } catch (e: any) {
      setState((s) => ({
        ...s,
        isLoading: false,
        error: e.response?.data?.message || 'Login failed',
      }));
    }
  }, [router]);

  // ✅ Logout
  const logout = useCallback(() => {
    bankFacade.logout();
    localStorage.removeItem('accessToken');

    setState({
      user: null,
      isAuthenticated: false,
      isLoading: false,
      error: null,
    });

    router.push('/login');
  }, [router]);

  return {
    ...state,
    login,
    logout,
  };
};
