// src/api/ApiClient.ts
import axios, { AxiosInstance, InternalAxiosRequestConfig } from 'axios';

const BASE_URL = 'http://localhost:3000';


const PUBLIC_ENDPOINTS = [
    '/auth/login',
];

class ApiClient {
    private client: AxiosInstance;

    constructor() {
        this.client = axios.create({
            baseURL: BASE_URL,
            headers: {
                'Content-Type': 'application/json',
            },
        });

        // ✅ Request interceptor
        this.client.interceptors.request.use(
            (config: InternalAxiosRequestConfig) => {
                const isPublicEndpoint = PUBLIC_ENDPOINTS.some((endpoint) =>
                    config.url?.includes(endpoint),
                );

                if (!isPublicEndpoint) {
                    const token = localStorage.getItem('accessToken');
                    if (token) {
                        config.headers.Authorization = `Bearer ${token}`;
                    }
                }

                return config;
            },
            (error) => Promise.reject(error),
        );

        // ✅ Response interceptor
        this.client.interceptors.response.use(

            (response) => response,
            (error) => {
                if (error.response?.status === 401) {
                    console.error('Unauthorized access. Redirecting to login.');

                    localStorage.removeItem('accessToken');

                }

                return Promise.reject(error);
            },
        );
    }

    public getClient(): AxiosInstance {
        return this.client;
    }
}

export const apiClient = new ApiClient().getClient();
