// src/api/AuthService.ts
import { apiClient } from './ApiClient';
import { LoginDto, AuthResponse } from '@/types';

export class AuthService {
  private readonly endpoint = '/auth';



  async login(credentials: LoginDto): Promise<AuthResponse> {
    const response = await apiClient.post<AuthResponse>(`${this.endpoint}/login`, credentials);

    localStorage.setItem('accessToken', response.data.access_token);
    return response.data;
  }

  /**
   * Simulates a logout by clearing the stored token.
   */
  logout(): void {
    localStorage.removeItem('accessToken');
    // In a real app, you might also call a backend logout endpoint to invalidate the token
  }
}
